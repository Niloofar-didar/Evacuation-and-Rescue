package evacuation;

import com.anylogic.engine.*;

/**
 * Dimensions
 */
@AnyLogicInternalCodegenAPI
public class HyperArrays {

}
