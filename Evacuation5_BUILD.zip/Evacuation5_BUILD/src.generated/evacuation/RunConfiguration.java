package evacuation;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Currency;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.Stack;
import java.util.Timer;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import com.anylogic.engine.connectivity.ResultSet;
import com.anylogic.engine.connectivity.Statement;
import com.anylogic.engine.elements.*;
import com.anylogic.engine.markup.Network;
import com.anylogic.engine.Position;
import com.anylogic.engine.markup.PedFlowStatistics;
import com.anylogic.engine.markup.DensityMap;


import static java.lang.Math.*;
import static com.anylogic.engine.UtilitiesArray.*;
import static com.anylogic.engine.UtilitiesCollection.*;
import static com.anylogic.engine.presentation.UtilitiesColor.*;
import static com.anylogic.engine.HyperArray.*;

import com.anylogic.engine.*;
import com.anylogic.engine.analysis.*;
import com.anylogic.engine.connectivity.*;
import com.anylogic.engine.database.*;
import com.anylogic.engine.gis.*;
import com.anylogic.engine.markup.*;
import com.anylogic.engine.presentation.*;

import com.anylogic.libraries.pedestrian.*;
import com.anylogic.libraries.processmodeling.*;

import com.mysema.query.Tuple;
import com.mysema.query.sql.SQLBindings;
import static evacuation.DBDescriptor.*;

import static com.anylogic.engine.Utilities.*;
import java.util.Optional;

public class RunConfiguration implements IRunConfiguration<Main> {
	/**
	 * Constructor
	 */
	public RunConfiguration() {
	}

	@Override
	@AnyLogicInternalCodegenAPI
	public void setupEngine(Engine engine) {
    engine.setATOL( 1.0E-5 );
    engine.setRTOL( 1.0E-5 );
    engine.setTTOL( 1.0E-5 );
    engine.setHTOL( 0.001 );
    engine.setSolverODE( Engine.SOLVER_ODE_EULER );
    engine.setSolverNAE( Engine.SOLVER_NAE_MODIFIED_NEWTON );
    engine.setSolverDAE( Engine.SOLVER_DAE_RK45_NEWTON );
    engine.setVMethods( 427029 );

		engine.setSimultaneousEventsSelectionMode(Engine.EVENT_SELECTION_LIFO);

		engine.setStartTime( 0.0 );
		engine.setTimeUnit( MINUTE );
		engine.setStartDate( toDate( 2012, JULY, 23, 8, 0, 0 ) );
		engine.setStopDate( toDate( 2012, JULY, 23, 22, 0, 0 ) );
	}

	@Override
    public Main createRootAgent(Engine engine) {
    	return new Main( engine, null, null );
    }
	
	@Override
	@AnyLogicInternalCodegenAPI
	public void setupRootParameters( final Main root, boolean callOnChangeActions,
			IRunValueAccessor parameterSource ) {

		double alarmTime_xjal =
			parameterSource.getValue("Alarm time", double.class, null)
					.orElseGet(() -> root
						._alarmTime_DefaultValue_xjal());
		if (callOnChangeActions) {
			root.set_alarmTime( alarmTime_xjal );
		} else {
			root.alarmTime = alarmTime_xjal;
		}
		double visitorArrivalMultiplier_xjal =
			root._visitorArrivalMultiplier_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_visitorArrivalMultiplier( visitorArrivalMultiplier_xjal );
		} else {
			root.visitorArrivalMultiplier = visitorArrivalMultiplier_xjal;
		}
		boolean addExit_xjal =
			parameterSource.getValue("Two exits", boolean.class, null)
					.orElseGet(() -> root
						._addExit_DefaultValue_xjal());
		if (callOnChangeActions) {
			root.set_addExit( addExit_xjal );
		} else {
			root.addExit = addExit_xjal;
		}
		double workerArrivalRate_xjal =
			root._workerArrivalRate_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_workerArrivalRate( workerArrivalRate_xjal );
		} else {
			root.workerArrivalRate = workerArrivalRate_xjal;
		}
		boolean addExit1_xjal =
			root._addExit1_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_addExit1( addExit1_xjal );
		} else {
			root.addExit1 = addExit1_xjal;
		}
		boolean active_dynamic_xjal =
			root._active_dynamic_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_active_dynamic( active_dynamic_xjal );
		} else {
			root.active_dynamic = active_dynamic_xjal;
		}
		TargetLine safe_exit_xjal =
			root._safe_exit_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_safe_exit( safe_exit_xjal );
		} else {
			root.safe_exit = safe_exit_xjal;
		}
		double newvisitorArrivalRate_xjal =
			root._newvisitorArrivalRate_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_newvisitorArrivalRate( newvisitorArrivalRate_xjal );
		} else {
			root.newvisitorArrivalRate = newvisitorArrivalRate_xjal;
		}
		boolean active_predict_help_xjal =
			root._active_predict_help_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_active_predict_help( active_predict_help_xjal );
		} else {
			root.active_predict_help = active_predict_help_xjal;
		}
		MyAgent fire_center_xjal =
			root._fire_center_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_fire_center( fire_center_xjal );
		} else {
			root.fire_center = fire_center_xjal;
		}
		double[] dis_from_fire_xjal =
			root._dis_from_fire_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_dis_from_fire( dis_from_fire_xjal );
		} else {
			root.dis_from_fire = dis_from_fire_xjal;
		}
		double fire_speed_xjal =
			root._fire_speed_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_fire_speed( fire_speed_xjal );
		} else {
			root.fire_speed = fire_speed_xjal;
		}
		double now_time_xjal =
			root._now_time_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_now_time( now_time_xjal );
		} else {
			root.now_time = now_time_xjal;
		}
		boolean dynamic_help_xjal =
			root._dynamic_help_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_dynamic_help( dynamic_help_xjal );
		} else {
			root.dynamic_help = dynamic_help_xjal;
		}
		MyAgent[] connectedag2_xjal =
			root._connectedag2_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_connectedag2( connectedag2_xjal );
		} else {
			root.connectedag2 = connectedag2_xjal;
		}
		boolean active_safest_xjal =
			root._active_safest_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_active_safest( active_safest_xjal );
		} else {
			root.active_safest = active_safest_xjal;
		}
		boolean static_withdoor_sensor_xjal =
			root._static_withdoor_sensor_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_static_withdoor_sensor( static_withdoor_sensor_xjal );
		} else {
			root.static_withdoor_sensor = static_withdoor_sensor_xjal;
		}
		boolean explosion_xjal =
			root._explosion_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_explosion( explosion_xjal );
		} else {
			root.explosion = explosion_xjal;
		}
		MyAgent[] floor1_agents_xjal =
			root._floor1_agents_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_floor1_agents( floor1_agents_xjal );
		} else {
			root.floor1_agents = floor1_agents_xjal;
		}
		MyAgent[] floor2_agents_xjal =
			root._floor2_agents_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_floor2_agents( floor2_agents_xjal );
		} else {
			root.floor2_agents = floor2_agents_xjal;
		}
		boolean a1_xjal =
			root._a1_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_a1( a1_xjal );
		} else {
			root.a1 = a1_xjal;
		}
		boolean a2_xjal =
			root._a2_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_a2( a2_xjal );
		} else {
			root.a2 = a2_xjal;
		}
		boolean a3_xjal =
			root._a3_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_a3( a3_xjal );
		} else {
			root.a3 = a3_xjal;
		}
		boolean a4_xjal =
			root._a4_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_a4( a4_xjal );
		} else {
			root.a4 = a4_xjal;
		}
		int coffee_counter_xjal =
			root._coffee_counter_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_coffee_counter( coffee_counter_xjal );
		} else {
			root.coffee_counter = coffee_counter_xjal;
		}
		long total_beforealarm_xjal =
			root._total_beforealarm_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_total_beforealarm( total_beforealarm_xjal );
		} else {
			root.total_beforealarm = total_beforealarm_xjal;
		}
		boolean as1_xjal =
			root._as1_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_as1( as1_xjal );
		} else {
			root.as1 = as1_xjal;
		}
		boolean as3_2_xjal =
			root._as3_2_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_as3_2( as3_2_xjal );
		} else {
			root.as3_2 = as3_2_xjal;
		}
		boolean a3_4_xjal =
			root._a3_4_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_a3_4( a3_4_xjal );
		} else {
			root.a3_4 = a3_4_xjal;
		}
		boolean a1_1_xjal =
			root._a1_1_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_a1_1( a1_1_xjal );
		} else {
			root.a1_1 = a1_1_xjal;
		}
		boolean a3_2_xjal =
			root._a3_2_DefaultValue_xjal();
		if (callOnChangeActions) {
			root.set_a3_2( a3_2_xjal );
		} else {
			root.a3_2 = a3_2_xjal;
		}
	}
	
	@Override
	@AnyLogicInternalAPI
	public void getOutputValues(Main root, IRunOutputsConsumer outputsConsumer) {
		outputsConsumer.storeOutput( "Number of people in building by minutes|success_rate", root.plot.get( 0 ) );
		outputsConsumer.storeOutput( "Number of people in building by minutes| PeopleInside", root.plot.get( 1 ) );
		outputsConsumer.storeOutput( "Number of people in building by minutes|Dataset(time,inside)", root.plot.get( 2 ) );
		outputsConsumer.storeOutput( "Evacuation time in minutes", double.class, null, root.evacTime );
	}

}
